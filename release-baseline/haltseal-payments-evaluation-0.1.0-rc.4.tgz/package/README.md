# HALTSEAL payment SDK for JavaScript

Dependency-free ESM client for Node 22+ and the local Payment API evaluation.
Build and install the local tarball using the service README. This name is not
claimed to be published on npm. Type declarations are included.

`approveSource` requires the issuer's original JSON string. Do not parse/rewrite
signed nanosecond timestamps with JavaScript numbers. Save the operation ID
before dispatch. An uncertain create reply raises `UncertainDispatch` with
`operationId` and LOOKUP_OPERATION. Resume/cancel/recover failures retain
`attemptId` and LOOKUP_ATTEMPT. No automatic retry or fallback occurs.
Read failures raise TransportError with REPEAT_READ; invalid input raises
ValidationError before sending. Lookup 404 is not proof of original closure.
`error.recovery` is frozen, JSON serializable and uses the same snake_case keys
as the Python recovery context. It includes origin, identity, request fingerprint
and next action, without the API key or signed payload.

`timeoutMs` bounds fetch and streamed body consumption. Responses are limited to
1 MiB; redirects are refused. Optional `fetchImpl` must obey one-send, verified
TLS and no-redirect/no-retry requirements. `close()` prevents new calls; the owner
closes any injected connection pools. `onEvent` emits redacted request traces.

See the service's docs/SDK_RECOVERY.md and docs/INTEGRATION_ACCEPTANCE.md, or
https://github.com/meridianverity/haltseal.com/tree/main/services/payment-api/docs.

All decisions must be checked explicitly. HOLD/REFUSE block the new financial
step. ACCEPT is not proof of payment. Production remains NO_GO.
